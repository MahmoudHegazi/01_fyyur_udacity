#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#----------------------------------------------------------------------------#
# Imports
#----------------------------------------------------------------------------#

import json
import dateutil.parser
import babel
from flask import Flask, render_template, request, Response, flash, redirect, url_for, jsonify
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import logging
from logging import Formatter, FileHandler
from flask_wtf import Form
from forms import *
import os, sys
from datetime import datetime
import calendar
import dateutil
import datetime
from datetime import datetime

#----------------------------------------------------------------------------#
# App Config.
#----------------------------------------------------------------------------#

app = Flask(__name__)
moment = Moment(app)
app.config.from_object('config')
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://purple_fish:123@localhost:5432/fyyur'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
#this to show arabic address
app.config['JSON_AS_ASCII'] = False
app.config["IMAGE_UPLOADS"] = 'static/uploads'
db = SQLAlchemy(app)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://purple_fish:123@localhost:5432/'


#----------------------------------------------------------------------------#
# image upload handlers.
#----------------------------------------------------------------------------#

UPLOAD_FOLDER = 'static'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

# datetime object containing current date and time (function to get time )
def time_now():
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    return dt_string

# TODO: connect to a local postgresql database

#----------------------------------------------------------------------------#
# Models.
#----------------------------------------------------------------------------#




class ErrorBoard(db.Model):
    __tablename__ = 'error_board'

    id = db.Column(db.Integer, primary_key=True)
    table_name = db.Column(db.String)
    path = db.Column(db.String(120))
    error_date = db.Column(db.String(500))
    sys_message = db.Column(db.String(500))





show = db.Table('show',
db.Column('id', db.Integer, primary_key=True),
db.Column('venue_id', db.Integer, db.ForeignKey('Venue.id') ,nullable=False),
db.Column('artist_id',db.Integer, db.ForeignKey('Artist.id') ,nullable=False),
db.Column('start_time',db.String, nullable=False),
db.Column('image_link',db.String),
db.Column('venue_name',db.String),
db.Column('artist_name',db.String)

)

class Venue(db.Model):
    __tablename__ = 'Venue'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(120))
    phone = db.Column(db.String(120))
    image_link = db.Column(db.String(500), nullable=False, default='/static/img/covid_venues_joey_bruce_900_611_90.jpg')
    facebook_link = db.Column(db.String(120))
    website = db.Column(db.String)
    shows = db.relationship('Artist', secondary=show, backref=db.backref('venue'), lazy=True)




    # TODO: implement any missing fields, as a database migration using Flask-Migrate
    # i hope it

class Artist(db.Model):
    __tablename__ = 'Artist'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(120))
    genres = db.Column(db.String(120))
    image_link = db.Column(db.String(500))
    facebook_link = db.Column(db.String(120), nullable=False, default='/static/img/84241059_189132118950875_4138507100605120512_n.jpg')
    website = db.Column(db.String)
    shows = db.relationship('Venue', secondary=show, backref=db.backref('artist') ,lazy=True)


def get_time():
    now = datetime.now()
    dt_string = now.strftime("%A,%w %d,%Y %H:%M:%S")
    return dt_string





# search function handle




def searchvenue():
    alldata = []

    try:
        allvenues = Venue.query.order_by('id').all()
        for one_venue in allvenues:
            venue_id = str(one_venue.id)
            vname = str(one_venue.name.lower())
            vaddress = str(one_venue.address.lower())
            vgeneres = str(one_venue.generes.lower())
            vcity = str(one_venue.city.lower())
            vname_object = {'table_id':venue_id,'search_term':vname,'name':one_venue.name}
            vaddress_object = {'table_id':venue_id,'search_term':vaddress,'name':one_venue.name}
            vgeneres_object = {'table_id':venue_id,'search_term':vgeneres,'name':one_venue.name}
            vcity_object = {'table_id':venue_id,'search_term':vcity,'name':one_venue.name}

            if vname_object not in alldata:
                alldata.append(vname_object)

            if vaddress_object not in alldata:
                alldata.append(vaddress_object)

            if vgeneres_object not in alldata:
                alldata.append(vgeneres_object)

            if vcity_object not in alldata:
                alldata.append(vcity_object)
    except:
        alldata = []
    return alldata

def search_artists():
    try:
        allartists = db.session.query(Artist).order_by('id').all()
        for one_artist in allartists:
            artist_id = str(one_artist.id)
            aname = str(one_artist.name.lower())
            acity = str(one_artist.city.lower())
            awebsite = str(one_artist.website.lower())
            aname_object = {'table_id':artist_id,'search_term':time_value, 'name':one_artist.name}
            acity_object = {'table_id':artist_id,'search_term':venue_name, 'name':one_artist.name}
            awebsite_object = {'table_id':artist_id,'search_term':artist_name, 'name':one_artist.name}
            if aname_object not in alldata:
                alldata.append(aname_object)

            if acity_object not in alldata:
                alldata.append(acity_object)

            if awebsite_object not in alldata:
                alldata.append(awebsite_object)
    except:
        allartists = []
    return allvenues



# this function return on time list of venues id and artist id
# to be used in custom_show_form (add User ID's in select shows/create)
def get_venue_artist_ids():
    venues_id_list = []
    artist_id_list = []
    venues = []
    artists = []
    error = False
    sys_message = ''
    try:
        venues = Venue.query.order_by('id').all()
        artists = Artist.query.order_by('id').all()
        for v in venues:
            if v.id not in venues_id_list:
                venues_id_list.append(v.id)
            else:
                continue
        for a in artists:
            if a.id not in artist_id_list:
                artist_id_list.append(a.id)
            else:
                continue
    except:
        #if no venues and arists add empty lists to handle errors
        print(sys.exc_info())
        sys_message = str(sys.exc_info())
        error = True
    finally:
        db.session.close()
    if not error and len(venues) > 0:
        return {'cod':200,'venues':venues_id_list,'artists':artist_id_list}
    else:
        return {'cod':403,'message':sys_message,'venues':[],'artists':[]}

# some soultion for better UI not allowed in forms
# this form static if you added new venue restart the server to update it save data
class Show_advanced_form(Form):

    # this step to create 2 lists contains the id for venues and artists better UI
    artists_venues_ids = get_venue_artist_ids()
    artist_id =SelectField(
        u'artist_id', validators=[DataRequired()],
        choices=artists_venues_ids['venues'])
    venue_id = SelectField(
        u'venue_id', validators=[DataRequired()],
        choices=artists_venues_ids['artists'])
    image_link = FileField(
            'image_link', validators=[DataRequired()])
    start_time = DateTimeField(
        u'start_time',
        validators=[DataRequired()],
        default= datetime.today()
    )


    # TODO: implement any missing fields, as a database migration using Flask-Migrate

# TODO Implement Show and Artist models, and complete all model relationships and properties, as a database migration.


db.create_all()
db.session.commit()
#----------------------------------------------------------------------------#
# Filters.
#----------------------------------------------------------------------------#

def format_datetime(value, format='medium'):
  date = dateutil.parser.parse(value)
  if format == 'full':
      format="EEEE MMMM, d, y 'at' h:mma"
  elif format == 'medium':
      format="EE MM, dd, y h:mma"
  return babel.dates.format_datetime(date, format)

app.jinja_env.filters['datetime'] = format_datetime

#----------------------------------------------------------------------------#
# Controllers.
#----------------------------------------------------------------------------#

@app.route('/')
def index():
  return render_template('pages/home.html')



###########################################################
#this function to handle the upcoming and coming
##########################################################

def is_upcoming(time_to_check):
    x = datetime.today()
    checker = datetime.strptime(time_to_check, '%Y-%m-%d %H:%M:%S')
    if checker > x:
        return True
    else:
        return False
def get_upcoming_and_pas(dynamic_id,is_artist):
    error = False
    result = {'upcoming_shows':[],'past_shows':[]}
    project_data = []
    past_shows = []
    upcoming_shows = []

    if is_artist == True:
        all_shows = db.session.query(show).filter_by(artist_id=dynamic_id).order_by('id').all()
    else:
        all_shows = db.session.query(show).filter_by(venue_id=dynamic_id).order_by('id').all()

    # make the data ready in project Data  show id and bool if it comming or past
    # for some reason I have to do like that
    for one_show in all_shows:
        if one_show.start_time:
            try:
                is_it_comming = is_upcoming(one_show.start_time)
            except:
                continue
            project_data.append({'show_id':one_show.id,'date_bool':is_it_comming})
            if one_show.start_time == 'False':
                return 'yes'
        else:
            continue
    if is_artist == True:
        for valid_show in project_data:
            showid = valid_show['show_id']
            get_show = db.session.query(show).filter_by(id=showid).first()
            # if the date_bool true thats mean the show date > current date
            if valid_show['date_bool']:
                if get_show != None:
                    upcoming_shows.append({'venue_id':get_show.venue_id,'venue_name':get_show.venue_name,
                    'venue_image_link':get_show.image_link,'start_time':get_show.start_time})
            else:
                if get_show != None:
                    # this step to handle if no image found it required but I handle every thing
                    past_shows.append({'venue_id':get_show.venue_id,'venue_name':get_show.venue_name,
                    'venue_image_link':get_show.image_link,'start_time':get_show.start_time})
    else:
        for valid_show in project_data:
            showid = valid_show['show_id']
            get_show = db.session.query(show).filter_by(id=showid).first()
            # if the date_bool true thats mean the show date > current date
            if valid_show['date_bool']:
                if get_show != None:
                    upcoming_shows.append({'artist_id':get_show.artist_id,'artist_name':get_show.artist_name,
                    'artist_image_link':get_show.image_link,'start_time':get_show.start_time})
            else:
                if get_show != None:
                    # this step to handle if no image found it required but I handle every thing
                    past_shows.append({'venue_id':get_show.venue_id,'venue_name':get_show.venue_name,
                    'artist_image_link':get_show.image_link,'start_time':get_show.start_time})


    result = {'upcoming_shows':upcoming_shows,'past_shows':past_shows,'len_upcoming':len(upcoming_shows),'len_past':len(past_shows)}
    return result



#  Venues  Include Advanced Function
#  ----------------------------------------------------------------

@app.route('/venues')
def venues():

  # TODO: replace with real venues data.
  # num_shows should be aggregated based on number of upcoming shows per venue.
    venues = Venue.query.order_by('id').all()
    all_city = []
    venues_citis = []
    data = []
    # this for loop will append eaach unique city with its state for dynamic header
    for i in venues:
        template_ai = str(i.city) + '-t-' + str(i.state)
        if template_ai not in all_city:
            all_city.append(i.city + '-t-' + str(i.state))
        else:
            continue


  # AI Function To automate get the city dynamicly instead of defined city for every city in world
  # i called it AI becuse I do not need to teach app each city it will learn them
    for single_area in all_city:
        city_name = single_area.split('-t-')[0]
        state = single_area.split('-t-')[1]
        # if this query not like this use only city it will return not valid data
        # some venues can have same city but not state
        all_city_veneues = Venue.query.filter_by(city=city_name).filter_by(state=state).order_by('id').all()
        data_container = {'city':city_name,'state':state,'venues':[]}
        for ven in all_city_veneues:
            data_to_append = {'id':ven.id,'name':ven.name,'num_upcoming_shows':0}
            data_container['venues'].append(data_to_append)
        data.append(data_container)
    return render_template('pages/venues.html', areas=data);
      #return jsonify(data)
""" old static way
  data=[{
    "city": "San Francisco",
    "state": venues[0].state,
    "venues": venues_citis
  }, {
    "city": "New York",
    "state": "NY",
    "venues": [{
      "id": 2,
      "name": "The Dueling Pianos Bar",
      "num_upcoming_shows": 0,
    }]
  }]
"""



@app.route('/venues/search', methods=['POST'])
def search_venues():
    res_list = []
    # TODO: implement search on artists with partial string search. Ensure it is case-insensitive.
    # seach for Hop should return "The Musical Hop".
    # search for "Music" should return "The Musical Hop" and "Park Square Live Music & Coffee"
    if request.method == 'POST':
        search_term = '%s' % request.form.get('search_term', '').lower()

        if search_term != '':
            venues_data_list = Venue.query.order_by('id').all()
            artists_data_list = Artist.query.order_by('id').all()
            # search in venues
            for n in venues_data_list:
                if search_term in str(n.name).lower():
                    res_list.append({'id':n.id,'name':n.name,'type':'venue'})
                else:
                    continue

            # search in all artist names dynamic handled in search.html for link
            for a in artists_data_list:
                if search_term in str(a.name).lower():
                    res_list.append({'id':a.id,'name':a.name,'type':'artist'})
                else:
                    continue

            if len(res_list) > 0:
                count_responses = len(res_list)
                response={"count":count_responses, 'data':res_list}
                return render_template('pages/search_venues.html', results=response, search_term=search_term)

            else:
                response={ "count": 0}
                return render_template('pages/search_venues.html', results=response, search_term=request.form.get('search_term', ''))

            #return str(search_term)


# search artist




@app.route('/venues/<int:venue_id>')
def show_venue(venue_id):
    # shows the venue page with the given venue_id
    # TODO: replace with real venue data from the venues table, using
    venue = Venue.query.filter_by(id=venue_id).first()
    # this function return result object that contains the upcoming and past shows for given artist id
    # by send second pramter true it will handle it as artist else will handle venue write less code
    listed_shows = get_upcoming_and_pas(venue_id,False)

    data={
      "id": venue.id,
      "name": venue.name,
      #"genres": [venue.genres],
      "address": venue.address,
      "city": venue.city,
      "state": venue.state,
      "phone": venue.phone,
      "website": venue.website,
      "facebook_link": venue.facebook_link,
      "seeking_talent": True,
      "seeking_description": "We are on the lookout for a local artist to play every two weeks. Please call us.",
      "image_link": "https://images.unsplash.com/photo-1543900694-133f37abaaa5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
      "past_shows": listed_shows['past_shows'],
      "upcoming_shows": listed_shows['upcoming_shows'],
      "past_shows_count": listed_shows['len_past'],
      "upcoming_shows_count": listed_shows['len_upcoming'],
    }
    #data = list(filter(lambda d: d['id'] == venue_id, [data1, data2, data3]))[0]
    return render_template('pages/show_venue.html', venue=data)

#  Create Venue
#  ----------------------------------------------------------------

@app.route('/venues/create', methods=['GET'])
def create_venue_form():
  form = VenueForm()
  return render_template('forms/new_venue.html', form=form)

@app.route('/venues/create', methods=['POST'])
def create_venue_submission():
    error = False
    error_bool = False
    sys_message = ''
    if request.method == "POST":
        s_name = '%s' % request.form['name']
        s_city = '%s' % request.form['city']
        s_state = '%s' % request.form['state']
        s_address = request.form['address']
        s_phone = '%s' % request.form['phone']
        s_facebook_link = '%s' % request.form['facebook_link']
        s_website = '%s' % request.form['website']
        # upload image
        if request.files['image_link'] and request.files['image_link'].filename:
            main_image_object = request.files['image_link']
            filename = '%s' % main_image_object.filename
            main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
            main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
        project_data = {'name':s_name,'city':s_city,'state':s_state,
        'address':s_address,'phone':s_phone,'facebook_link':s_facebook_link,'image':main_image,
        'website':s_website}
        # remove the comment for test all values
        #return jsonify(project_data)

        try:
            new_venue = Venue(name=project_data['name'], city=project_data['city'],
            state=project_data['state'], address=project_data['address'],phone=project_data['phone'],
            facebook_link=project_data['facebook_link'], image_link=project_data['image'],website=project_data['website'])
            # add the new artist class to the session
            db.session.add(new_venue)
            #itemto_edit.main_image = main_image
            db.session.commit()
        except:
            # if any errors in commit set error to true for troubleshoot and rollback the session
            error = True
            sys_message = str(sys.exc_info())
            db.session.rollback()
        finally:
            # always close the session
            db.session.close()
        if s_name != '' and not error:
            flash('Venue ' + request.form['name'] + ' was successfully listed!')
            return render_template('pages/home.html')
        else:
            form = VenueForm()
            try:
                time_now_var = str(time_now())
                new_error = ErrorBoard(table_name='Venue', path='/venues/create', error_date=time_now_var, sys_message=sys_message)
                db.session.add(new_error)
                db.session.commit()
                error_id = new_error.id
            except:
                error_bool = True
                sys_message = str(sys.exc_info())
                db.session.rollback()
            finally:
                db.session.close()
            if not error_bool:
                flash('Sorry, Could not Create your new venue right now try after 2 minutes Created Error recored %s' %error_id)
                return render_template('forms/new_venue.html', form=form)
            else:
                return str(sys_message)
                flash('Sorry, Could not Create your new venue right now Contact Support Error 012')
                return render_template('forms/new_venue.html', form=form)

    return render_template('pages/home.html')



# we do not need id var I use fetch and AJAX like open weather API
@app.route('/shows/delete', methods=['DELETE'])
def delete_show():
    handle_error = False
    sys_message = ''
    s_show_id = '%s' % request.get_json().get('show_id')
    # TODO: Complete this endpoint for taking a venue_id, and using AJAX and Fetch
    # SQLAlchemy ORM to delete a record. Handle cases where the session commit could fail.
    # BONUS CHALLENGE: Implement a button to delete a Venue on a Venue Page, have it so that
    # clicking that button delete it from the db then redirect the user to the homepage

    if request.method == 'DELETE':
        # get the section to delete
        show_to_delete = db.session.query(show).filter_by(id=s_show_id).first()

        import psycopg2

        try:

            # i copied this static part for conection and use SQL but edited it
            connection = psycopg2.connect(user="purple_fish",
                                          password="123",
                                          host="127.0.0.1",
                                          port="5432",
                                          database="fyyur")

            cursor = connection.cursor()

            # Update single record now
            sql_delete_query = """Delete from show where id = %s"""
            cursor.execute(sql_delete_query, (s_show_id, ))
            connection.commit()
            count = cursor.rowcount
            print(count, "Record deleted successfully ")

        except (Exception, psycopg2.Error) as error:
            # i added this part
            handle_error = True
            connection.rollback()
            sys_message = str(sys.exc_info())
            print("Error in Delete operation", error)

        finally:
            # closing database connection.
            if (connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")
        if not handle_error:
            return jsonify({'cod':200,'message':'successfully deleted show with id %s ' % s_show_id})
        else:
            return jsonify({'code':403,'message':'Sorry Could not Delete the Show with id %s ' % s_show_id ,'sys_message':sys_message})

    return None


def sql_remove(id_remove):
    handle_error = False
    sys_message = ''
    import psycopg2

    try:

        # i copied this static part for conection and use SQL but edited it
        connection = psycopg2.connect(user="purple_fish",
                                      password="123",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="fyyur")

        cursor = connection.cursor()

        # Update single record now
        sql_delete_query = """Delete from show where id = %s"""
        cursor.execute(sql_delete_query, (id_remove, ))
        connection.commit()
        count = cursor.rowcount
        print(count, "Record deleted successfully ")

    except (Exception, psycopg2.Error) as error:
        # i added this part
        handle_error = True
        connection.rollback()
        sys_message = str(sys.exc_info())
        print("Error in Delete operation", error)

    finally:
        # closing database connection.
        if (connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")
    if not psycopg2.Error:
        return True
    else:
        return False




def sql_edit(show_id,property_to_edit, value):
    handle_error = False
    sys_message = ''
    import psycopg2
    try:

        # i copied this static part for conection and use SQL but edited it
        connection = psycopg2.connect(user="purple_fish",
                                      password="123",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="fyyur")

        cursor = connection.cursor()

        # Update single record now

        if property_to_edit == 'venueid':
            sql_update_query = """ UPDATE show SET venue_id = %s WHERE id = %s"""
        if property_to_edit == 'artistid':
            sql_update_query = """ UPDATE show SET artist_id = %s WHERE id = %s"""
        if property_to_edit == 'time':
            sql_update_query = """ UPDATE show SET start_time = %s WHERE id = %s"""
        if property_to_edit == 'image':
            sql_update_query = """ UPDATE show SET image_link = %s WHERE id = %s"""
        if property_to_edit == 'vname':
            sql_update_query = """ UPDATE show SET venue_name = %s WHERE id = %s"""
        if property_to_edit == 'aname':
            sql_update_query = """ UPDATE show SET artist_name = %s WHERE id = %s"""
        cursor.execute(sql_update_query, (value, show_id))
        connection.commit()
        count = cursor.rowcount
        print(count, "Record deleted successfully ")

    except (Exception, psycopg2.Error) as error:
        # i added this part
        handle_error = True
        connection.rollback()
        sys_message = str(sys.exc_info())
        print("Error in Delete operation", error)

    finally:
        # closing database connection.
        if (connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")
        if not handle_error:
            return True
        else:
            return False




def delete_show_venues(venue_id):
    deleted_count = 0
    venue_shows = db.session.query(show).filter_by(venue_id=venue_id).order_by('id').all()
    for ashow in venue_shows:
        deleted_count += 1
        # if any show remove it (this dynamic function can handle artist shows or venues shows)
        checker = sql_remove(ashow.id)
    return True


def delete_venue_id(venue_id):
    error = False
    try:
        venue_shows = db.session.query(Venue).filter_by(id=venue_id).delete()
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        return True
    else:
        return False



def delete_artist_shows(artist_id):
    deleted_count = 0
    artist_shows = db.session.query(show).filter_by(artist_id=artist_id).order_by('id').all()
    for ashow in artist_shows:
        deleted_count += 1
        # if any show remove it (this dynamic function can handle artist shows or venues shows)
        checker = sql_remove(ashow.id)
    return True

def delete_artist_id(artist_id):
    error = False
    try:
        artist_to_delete = db.session.query(Artist).filter_by(id=artist_id).delete()
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        return True
    else:
        return False


# we do not need id var I use fetch and AJAX like open weather API
@app.route('/venues/<int:venue_id>', methods=['DELETE'])
def delete_venue(venue_id):
    if request.method == 'DELETE':
        s_show_id = '%s' % venue_id
        # due to relationship DB create all shows for venue
        deleted_shows_count = delete_show_venues(s_show_id)
        if deleted_shows_count:
            deleted_venue_bool = delete_venue_id(venue_id)
            if deleted_venue_bool:
                return jsonify({'cod':200,'message':'AJAX successfully Deleted Venue with id %s and all its shows ' % venue_id})
            else:
                return jsonify({'cod':403,'message':'Could not Deleted'})


# new way DELETE with post method normal function without ajax
@app.route('/artists/<int:artist_id>/delete', methods=['POST'])
def delete_artist(artist_id):
    if request.method == 'POST':
        s_artistid = '%s' % artist_id
        # due to relationship DB create all shows for venue
        # this function take artist id and delete all rows in shows with that id
        deleted_shows_count = delete_artist_shows(s_artistid)
        if deleted_shows_count:
            #like the name it delete artist with error handle
            deleted_artist_bool = delete_artist_id(s_artistid)
            if deleted_artist_bool:
                flash('successfully Deleted Artist with ID: %s and all its shows ' % s_artistid)
                return redirect(url_for('index'))
            else:
                flash('Sorry Could Not Deleted Artist with ID: %s Right now try after 2 minutes like AWS' % s_artistid)
                return redirect(url_for('index'))


#  Artists
#  ----------------------------------------------------------------
@app.route('/artists')
def artists():
  # TODO: replace with real data returned from querying the database
  data = []
  artists = Artist.query.order_by('id').all()
  for one_artist in artists:
      an_artist = {'id':one_artist.id, 'name':one_artist.name}
      data.append(an_artist)
  return render_template('pages/artists.html', artists=data)

@app.route('/artists/search', methods=['POST'])
def search_artists():
    # TODO: implement search on artists with partial string search. Ensure it is case-insensitive.
    # seach for "A" should return "Guns N Petals", "Matt Quevado", and "The Wild Sax Band".
    # search for "band" should return "The Wild Sax Band".
    res_list = []

    if request.method == 'POST':
        search_term = '%s' % request.form.get('search_term', '').lower()

        if search_term != '':
            artists_data_list = Artist.query.order_by('id').all()
            venue_data_list = Venue.query.order_by('id').all()
            # search in all artist names
            for a in artists_data_list:
                if search_term in str(a.name).lower():
                    res_list.append({'id':a.id,'name':a.name,'type':'artist'})
                else:
                    continue
            # search in all venue names
            # due to rubric user can search for venue from artist and artist from venue
            for v in venue_data_list:
                if search_term in str(v.name).lower():
                    res_list.append({'id':a.id,'name':v.name,'type':'venue'})
                else:
                    continue
            if len(res_list) > 0:
                count_responses = len(res_list)
                response={"count":count_responses, 'data':res_list}
                return render_template('pages/search_artists.html', results=response, search_term=search_term)

            else:
                response={ "count": 0}
                return render_template('pages/search_artists.html', results=response, search_term=request.form.get('search_term', ''))



# handle edit function show
#-------------------------------------------

def edit_table_show(row_class,value_to_edit, value):
    error = False
    counter = 0
    #t_venue_name = Venue.query.filter_by(id=s_venueid).first()
    #t_artist_name = Artist.query.filter_by(id=s_artistid).first()
    # if venue id or artist id dynamic change the name not good but to late to change
    #new_venue_name = str(t_venue_name.name)
    #new_artist_name = str(t_artist_name.name)
    try:
        if value_to_edit == 'venueid':
            row_class.venue_id = value
            try:
                get_venue = Venue.query.filter_by(id=value).first()
            except:
                error = True
            finally:
                if not error and get_venue:
                    row_class.venue_name = value
                else:
                    # this handle if user add unvalid id for venue
                    flash('Sorry Not Found Venue with Given id %s ' %value)
                    redirect(url_for('shows'))
        # handle artist id change
        if value_to_edit == 'artistid':
            row_class.artist_id = value
            try:
                get_artist = Artist.query.filter_by(id=value).first()
            except:
                error = True
            finally:
                if not error and get_venue:
                    row_class.artist_name = get_artist.name
                else:
                    # this handle if user add unvalid id for venue
                    flash('Sorry Not Found Artist with Given id %s ' %value)
                    redirect(url_for('shows'))
        if value_to_edit == 'start_time':
            row_class.start_time = value
        if value_to_edit == 'image':
            row_class.image_link = value

        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        return True
    else:
        return False



# handle edit function
#-------------------------------------------

def edit_table_artist(row_class,value_to_edit, value):
    error = False
    counter = 0
    try:
        if value_to_edit == 'name':
            row_class.name = value
        if value_to_edit == 'city':
            row_class.city = value
        if value_to_edit == 'state':
            row_class.state = value
        if value_to_edit == 'generes':
            row_class.generes = value
        if value_to_edit == 'phone':
            row_class.phone = value
        if value_to_edit == 'facebook_link':
            row_class.facebook_link = value
        if value_to_edit == 'website':
            row_class.website = value
        if value_to_edit == 'image':
            row_class.image_link = value

        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        return True
    else:
        return False


# show edit ------------
#--------------------------------

#  Update Shows
#  ----------------------------------------------------------------
@app.route('/shows/<int:show_id>/edit', methods=['GET'])
def edit_show(show_id):
    form = ShowFormEdit()
    get_show = db.session.query(show).filter_by(id=show_id).first()
    # TODO: populate form with fields from show with ID <show_id> I did more than this alot
    if get_show != None:
        return render_template('forms/edit_show.html', form=form, show=get_show)
    else:
        # if wrong id given by url handle it
        flash('Show with id: %s Not found ' %show_id)
        return redirect(url_for('shows'))


@app.route('/shows/<int:show_id>/edit', methods=['POST'])
def edit_show_submission(show_id):
    # TODO: take values from the form submitted, and update existing
    # artist record with ID <artist_id> using the new attributes done and more
    image_bool = False
    main_image = ''
    edited_counter = 0
    projectData = {}
    # TODO: take values from the form submitted, and update existing
    # venue record with ID <venue_id> using the new attributesname, city, state, address, phone, website, image_link, genres,facebook_link
    image_bool = False
    if request.method == 'POST':
        get_show_by_id = db.session.query(show).filter_by(id=show_id).first()
        s_venueid = '%s' % request.form.get('venue_id', '')
        s_artistid = '%s' % request.form.get('artist_id', '')
        s_starte_date = '%s' % request.form.get('start_time', '')
        try:
            if request.files['image_link'] and request.files['image_link'].filename:
                main_image_object = request.files['image_link']
                filename = '%s' % main_image_object.filename
                main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
                main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
        except:
            image_bool = False
            main_image = ''
        finally:
            if main_image != '':
                image_bool = True
            else:
                image_bool = False

        # update part
        if s_venueid != '':
            # check if there are venue with given id if it select like my way it would be no need for this
            # please do not forget to restart flask server to show new venue id and artist id in create new show
            check_venue = Venue.query.filter_by(id=s_venueid).first()
            if check_venue != None:
                edite1 = sql_edit(show_id,'venueid',s_venueid)
                edite01 = sql_edit(show_id,'vname',check_venue.name)
                db.session.commit()
                if edite1 and edite01:
                    edited_counter += 1
                    projectData['venueid'] = s_venueid
                    projectData['venue_name'] = check_venue.name
            else:
                flash('sorry Could not Fond Venue With given id %s' %s_venueid)
                return redirect(url_for('shows'))

        if s_artistid != '':
            # check if there are venue with given id if it select like my way it would be no need for this
            # please do not forget to restart flask server to show new venue id and artist id in create new show
            check_artist = Artist.query.filter_by(id=s_artistid).first()
            if check_artist != None:
                edite2 = sql_edit(show_id,'artistid',s_artistid)
                edite02 = sql_edit(show_id,'aname',check_artist.name)
                db.session.commit()
                if edite2 and edite02:
                    edited_counter += 1
                    projectData['artistid'] = s_artistid
                    projectData['artist_name'] = check_artist.name
            else:
                flash('sorry Could not Fond Artist With given id %s' %s_artistid)
                return redirect(url_for('shows'))

        if s_starte_date != '':
             edite3 = sql_edit(show_id,'start',s_artistid)
             if edite3:
                 edited_counter += 1
                 projectData['start_time'] = s_starte_date

        if main_image != '':
             edite4 = sql_edit(show_id,'image',main_image)
             if edite4:
                 edited_counter += 1
                 projectData['image'] = main_image
        return jsonify({'message':'congrats You finished All tasks except search ','data':projectData})
        # check if name
        if edited_counter > 0:
            print(projectData)
            return jsonify(projectData)
            # long years was not know where the id come from
            flash('Successfully Edited Your Show count edites Done: %s \n Edited Items: %s' %   (edited_counter,str(projectData)))
            return redirect(url_for('shows'))
        else:
            flash('nothing has been changed in your Show  Edites Done: %s' % edited_counter)
            return redirect(url_for('shows'))

## -- end of update show


## -------- Artist

@app.route('/artists/<int:artist_id>')
def show_artist(artist_id):
    # shows the artist page with the given artist
    # TODO: replace with real artist data from the artist table, using artist_id
    artist = Artist.query.filter_by(id=artist_id).first()
    all_shows = db.session.query(show).filter_by(artist_id=artist_id).order_by('id').all()
    # this function return result object that contains the upcoming and past shows for given artist id
    # by send second pramter true it will handle it as artist else will handle venue write less code
    listed_shows = get_upcoming_and_pas(artist_id,True)
    #return str(listed_shows['past_shows'][0])
    data={
      "id": artist.id,
      "name": artist.name,
      "genres": [artist.genres],
      "city": artist.city,
      "state": artist.state,
      "phone": artist.phone,
      "website": artist.website,
      "facebook_link": artist.facebook_link,
      "seeking_venue": True,
      "seeking_description": "Looking for shows to perform at in the San Francisco Bay Area!",
      "image_link": artist.image_link,
      "past_shows": listed_shows['past_shows'],
      "upcoming_shows": listed_shows['upcoming_shows'],
      "past_shows_count": listed_shows['len_past'],
      "upcoming_shows_count": listed_shows['len_upcoming'],
    }
    #data = list(filter(lambda d: d['id'] == artist_id, [data1, data2, data3]))[0]
    return render_template('pages/show_artist.html', artist=data)




#  Update Artist
#  ----------------------------------------------------------------
@app.route('/artists/<int:artist_id>/edit', methods=['GET'])
def edit_artist(artist_id):
    form = ArtistForm()
    artist = Artist.query.filter_by(id=artist_id).first()
    # TODO: populate form with fields from artist with ID <artist_id> I did more than this alot
    if artist:
        return render_template('forms/edit_artist.html', form=form, artist=artist, l='Rock n Roll')
    else:
        # if wrong id given by url handle it
        flash('Artist with id: %s Not found ' %artist_id)
        return redirect(url_for('artists'))


@app.route('/artists/<int:artist_id>/edit', methods=['POST'])
def edit_artist_submission(artist_id):
    # TODO: take values from the form submitted, and update existing
    # artist record with ID <artist_id> using the new attributes done and more
    image_bool = False
    main_image = ''
    edited_counter = 0
    projectData = {}
    # TODO: take values from the form submitted, and update existing
    # venue record with ID <venue_id> using the new attributesname, city, state, address, phone, website, image_link, genres,facebook_link
    image_bool = False
    if request.method == 'POST':
        get_artist_by_id = Artist.query.filter_by(id=artist_id).first()
        s_name = '%s' % request.form.get('name', '')
        s_city = '%s' % request.form.get('city', '')
        s_state = '%s' % request.form.get('state', '')
        s_phone = request.form.get('phone', '')
        s_generes = request.form.getlist('genres',[])
        s_website = '%s' % request.form.get('website', '')
        s_facebook_link = '%s' % request.form.get('facebook_link', 'No facebook link')

        try:
            if request.files['image_link'] and request.files['image_link'].filename:
                main_image_object = request.files['image_link']
                filename = '%s' % main_image_object.filename
                main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
                # AI way to store the real file image path on our server not just Link we did it when we kids
                main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
        except:
            image_bool = False
            main_image = ''
        finally:
            if main_image != '':
                image_bool = True
            else:
                image_bool = False

        # this work with edit_table_artist to handle the edit with dynamic and lesss code and count edites
        if s_name != '':
             edite1 = edit_table_artist(get_artist_by_id, 'name' ,s_name)
             if edite1:
                 edited_counter += 1
                 projectData['name'] = s_name

        if s_city != '':
             edite2 = edit_table_artist(get_artist_by_id, 'city' ,s_city)
             if edite2:
                 edited_counter += 1
                 projectData['city'] = s_city

        if s_state != '':
             edite3 = edit_table_artist(get_artist_by_id, 'state' ,s_state)
             if edite3:
                 edited_counter += 1
                 projectData['state'] = s_state

        if s_phone != '':
             edite5 = edit_table_artist(get_artist_by_id, 'phone' ,s_phone)
             if edite5:
                 edited_counter += 1
                 projectData['phone'] = s_phone

        if s_facebook_link != '':
             edite6 = edit_table_artist(get_artist_by_id, 'facebook_link' ,s_facebook_link)
             if edite6:
                 edited_counter += 1
                 projectData['facebook_link'] = s_facebook_link

        if s_website != '':
             edite7 = edit_table_artist(get_artist_by_id, 'website' ,s_website)
             if edite7:
                 edited_counter += 1
                 projectData['website'] = s_website

        if s_generes != [] and s_generes != '':
             edite7 = edit_table_artist(get_artist_by_id, 'geners' ,s_generes)
             if edite7:
                 edited_counter += 1
                 projectData['website'] = s_generes

        if image_bool != False and main_image != '':
             edite8 = edit_table_artist(get_artist_by_id, 'image' ,main_image)
             if edite8:
                 edited_counter += 1
                 projectData['main_image'] = main_image
        # check if name
        if edited_counter > 0:
            print(projectData)
            flash('Congrats You Edited Artist Dynamic With Count : %s' % edited_counter)
            # long years was not know where the id come from
            flash('Successfully Edited Your Profile count edites Done: %s \n Edited Items: %s' %   (edited_counter,str(projectData)))
            return redirect(url_for('show_artist', artist_id=artist_id))
        else:
            flash('nothing has been changed in your Artist profile Count Edites Done: %s' % edited_counter)
            return redirect(url_for('show_artist', artist_id=artist_id))


@app.route('/venues/<int:venue_id>/edit', methods=['GET'])
def edit_venue(venue_id):
    error = False
    venueid = '%s' % venue_id
    try:
        venue = Venue.query.filter_by(id=venueid).first()
    except:
        error = True
        print(sys.exc_info())
    finally:
        db.session.close()
    if not error and venue:
        form = VenueEditForm()
        return render_template('forms/edit_venue.html', form=form, venue=venue)
    else:
        flash('Venue with id %s is Not Found Do not add id by yourself to url ' % venueid)
        return redirect(url_for('index'))

  # TODO: populate form with values from venue with ID <venue_id>



def edit_table(row_class,value_to_edit, value):
    error = False
    counter = 0
    try:
        if value_to_edit == 'name':
            row_class.name = value
        if value_to_edit == 'city':
            row_class.city = value
        if value_to_edit == 'state':
            row_class.state = value
        if value_to_edit == 'address':
            row_class.address = value
        if value_to_edit == 'phone':
            row_class.phone = value
        if value_to_edit == 'facebook_link':
            row_class.facebook_link = value
        if value_to_edit == 'website':
            row_class.website = value
        if value_to_edit == 'image':
            row_class.image_link = value

        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        return True
    else:
        return False






@app.route('/venues/<int:venue_id>/edit', methods=['POST'])
def edit_venue_submission(venue_id):
    main_image = ''
    edited_counter = 0
    projectData = {}
  # TODO: take values from the form submitted, and update existing
  # venue record with ID <venue_id> using the new attributesname, city, state, address, phone, website, image_link, genres,facebook_link
    image_bool = False
    if request.method == 'POST':
        get_venue_by_id = Venue.query.filter_by(id=venue_id).first()
        s_name = '%s' % request.form.get('name', '')
        s_city = '%s' % request.form.get('city', '')
        s_state = '%s' % request.form.get('state', '')
        s_address = request.form.get('address', '')
        s_phone = '%s' % request.form.get('phone', '')
        s_facebook_link = '%s' % request.form.get('facebook_link', '')
        s_website = '%s' % request.form.get('website', '')
        try:
            if request.files['image_link'] and request.files['image_link'].filename:
                main_image_object = request.files['image_link']
                filename = '%s' % main_image_object.filename
                main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
                main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
        except:
            image_bool = False
            main_image = ''
        finally:
            if main_image != '':
                image_bool = True
            else:
                image_bool = False

        # this work with edit_table to handle the edit with dynamic and lesss code and count edites
        if s_name != '':
             edite1 = edit_table(get_venue_by_id, 'name' ,s_name)
             if edite1:
                 edited_counter += 1
                 projectData['name'] = s_name

        if s_city != '':
             edite2 = edit_table(get_venue_by_id, 'city' ,s_city)
             if edite2:
                 edited_counter += 1
                 projectData['city'] = s_city

        if s_state != '':
             edite3 = edit_table(get_venue_by_id, 'state' ,s_state)
             if edite3:
                 edited_counter += 1
                 projectData['state'] = s_state

        if s_address != '':
             edite4 = edit_table(get_venue_by_id, 'address' ,s_address)
             if edite4:
                 edited_counter += 1
                 projectData['address'] = s_address

        if s_phone != '':
             edite5 = edit_table(get_venue_by_id, 'phone' ,s_phone)
             if edite5:
                 edited_counter += 1
                 projectData['phone'] = s_phone

        if s_facebook_link != '':
             edite6 = edit_table(get_venue_by_id, 'facebook_link' ,s_facebook_link)
             if edite6:
                 edited_counter += 1
                 projectData['facebook_link'] = s_facebook_link

        if s_website != '':
             edite7 = edit_table(get_venue_by_id, 'website' ,s_website)
             if edite7:
                 edited_counter += 1
                 projectData['website'] = s_website

        if image_bool != False and main_image != '':
             edite8 = edit_table(get_venue_by_id, 'image' ,main_image)
             if edite8:
                 edited_counter += 1
                 projectData['main_image'] = main_image
        # check if name
        if edited_counter > 0:
            print(projectData)
            flash('Congrats You Edited ITems Dynamic With Count : %s' % edited_counter)
            # long years was not know where the id come from
            return redirect(url_for('show_venue',venue_id=venue_id) )

        project_data = {'name':s_name,'city':s_city,'state':s_state,'address':s_address,'phone':s_phone, 'facebook_link':s_facebook_link,'image':main_image,'website':s_website}
        return project_data

      #return redirect(url_for('show_venue', venue_id=venue_id))

#  Create Artist
#  ----------------------------------------------------------------

@app.route('/artists/create', methods=['GET'])
def create_artist_form():
  form = ArtistForm()
  return render_template('forms/new_artist.html', form=form)

@app.route('/artists/create', methods=['POST'])
def create_artist_submission():
    error = False
    error_bool = False
    sys_message = ''
    if request.method == "POST":
        s_name = '%s' % request.form['name']
        s_city = '%s' % request.form['city']
        s_state = '%s' % request.form['state']
        s_phone = '%s' % request.form.get('phone', 'No phone')
        s_website = '%s' % request.form.get('website', 'No website')
        #s_image_link = '%s' % image_link
        #return list of genres form.language.data else first value el7 without js
        s_generes = request.form.getlist('genres')
        s_facebook_link = '%s' % request.form.get('facebook_link', 'No facebook link')
        # upload image
        if request.files['image_link'] and request.files['image_link'].filename:
            main_image_object = request.files['image_link']
            filename = '%s' % main_image_object.filename
            main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
            # AI way to store the real file image path on our server not just Link we did it when we kids
            main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
            project_data = {'name':s_name,'city':s_city,'state':s_state,
            'phone':s_phone,'generes':s_generes,'facebook_link':s_facebook_link,
            'image':main_image,'website':s_website}

        try:
            new_artist = Artist(name=project_data['name'], city=project_data['city'],
            state=project_data['state'], phone=project_data['phone'],
            genres=project_data['generes'],facebook_link=project_data['facebook_link'], image_link=project_data['image'],
            website=project_data['website'])
            # add the new artist class to the session
            db.session.add(new_artist)
            #itemto_edit.main_image = main_image
            db.session.commit()
        except:
            # if any errors in commit set error to true for troubleshoot and rollback the session
            return
            error = True
            sys_message = str(sys.exc_info())
            db.session.rollback()
        finally:
            # always close the session
            db.session.close()
        if s_name != '' and not error:
            flash('Artist ' + project_data['name'] + ' was successfully listed!')
            return render_template('pages/home.html')
        else:
            form = ArtistForm()
            try:
                # if unkown system error append it to database
                time_now_var = str(time_now())
                new_error = ErrorBoard(table_name='Artist', path='/artists/create', error_date='time_now_var', sys_message=sys_message)
                db.session.add(new_error)
                db.session.commit()
                error_id = new_error.id
            except:
                error_bool = True
                db.session.rollback()
            finally:
                db.session.close()
            if not error_bool:
                flash('Sorry, Could not Create your new Artist right now try after 2 minutes Created Error recored ID :%s' %error_id)
                return render_template('forms/new_artist.html', form=form)
            else:
                flash('Sorry, Could not Create your new venue right now Contact Support Error 011')
                return render_template('forms/new_artist.html', form=form)
    return render_template('forms/new_artist.html', form=form)
  # called upon submitting the new artist listing form form = ArtistForm()
  # TODO: insert form data as a new Venue record in the db, instead
  # TODO: modify data to be the data object returned from db insertion   name, city, state, phone, image_link, genres, facebook_link

  # on successful db insert, flash success
  #flash('Artist ' + request.form['name'] + ' was successfully listed!')
  # TODO: on unsuccessful db insert, flash an error instead.
  # e.g., flash('An error occurred. Artist ' + data.name + ' could not be listed.')
  #return render_template('pages/home.html')


#  Shows
#  ----------------------------------------------------------------

@app.route('/shows')
def shows():
    # displays list of shows at /shows
    # TODO: replace with real venues data.
    #       num_shows should be aggregated based on number of upcoming shows per venue.
    data = []
    # get list of all shows
    shows = db.session.query(show).order_by('id').all()
    for one_show in shows:
        # use for loop too create the ideal object for the show template
        show_object = {'show_id':one_show.id,'venue_id':one_show.venue_id,'venue_name':one_show.venue_name,
        'artist_id':one_show.artist_id,'artist_name':one_show.artist_name,
        'artist_image_link':one_show.image_link,'start_time':str(one_show.start_time)}
        data.append(show_object)
    return render_template('pages/shows.html', shows=data)

@app.route('/shows/create', methods=['GET'])
def create_shows():
  # renders form. do not touch. sorry I have to touch for UI
  form = Show_advanced_form()
  return render_template('forms/new_show.html', form=form)

@app.route('/shows/create', methods=['POST'])
def create_show_submission():
  # called to create new shows in the db, upon submitting new show listing form
  # TODO: insert form data as a new Show record in the db, instead
    error = False
    error_bool = False
    sys_message = ''
    if request.method == "POST":
        s_venueid = '%s' % request.form['venue_id']
        s_artistid = '%s' % request.form['artist_id']
        s_starte_date = '%s' % request.form['start_time']
        #return str([s_venueid,s_artistid,s_starte_date])
        # this to help and better performance due to long time query and search and .. add it in the table
        t_venue_name = Venue.query.filter_by(id=s_venueid).first()
        t_artist_name = Artist.query.filter_by(id=s_artistid).first()
        venue_name = str(t_venue_name.name)
        artist_name = str(t_artist_name.name)

        # for the project I will use query to show the name of artist and name of venue
        # upload image
        if request.files['image_link'] and request.files['image_link'].filename:
            main_image_object = request.files['image_link']
            filename = '%s' % main_image_object.filename
            main_image_object.save(os.path.join(app.config["IMAGE_UPLOADS"], filename))
            main_image= '/' + UPLOAD_FOLDER+'/uploads/'+filename
        project_data = {'venue_id':s_venueid,'artist_id':s_artistid,'start_date':s_starte_date,
        'image':main_image,'venue_name':venue_name,'artist_name':artist_name}
        # remove the comment for test all values
        #return jsonify(project_data)

        try:
           insert_stmnt = show.insert().values(venue_id=project_data['venue_id'],
           artist_id=project_data['artist_id'], start_time=project_data['start_date'],
           image_link=project_data['image'], venue_name=project_data['venue_name'],
           artist_name=project_data['artist_name'])
           db.session.execute(insert_stmnt)
           db.session.commit()
        except:
            # if any errors in commit set error to true for troubleshoot and rollback the session
            return
            error = True
            sys_message = str(sys.exc_info())
            db.session.rollback()
        finally:
            # always close the session
            db.session.close()
        if s_starte_date != '' and not error:
            flash('Show Will Start At ' + s_starte_date + ' and in venue ' + venue_name)
            return render_template('pages/home.html')
        else:
            #form = Show_advanced_form()
            try:
                # if unkown system error append it to database
                time_now_var = str(time_now())
                new_error = ErrorBoard(table_name='Show', path='/shows/create', error_date='time_now_var', sys_message=sys_message)
                db.session.add(new_error)
                db.session.commit()
                error_id = new_error.id
            except:
                error_bool = True
                db.session.rollback()
            finally:
                db.session.close()
            if not error_bool:
                flash('Sorry, Could not Create your new Show right now try after 2 minutes Created Error recored ID :%s' %error_id)
                return render_template('forms/new_show.html', form=form)
            else:
                flash('Sorry, Could not Create your new Show right now Contact Support Error 014')
                return render_template('forms/new_show.html', form=form)

  # on successful db insert, flash success
  #flash('Show was successfully listed!')
  # TODO: on unsuccessful db insert, flash an error instead.
  # e.g., flash('An error occurred. Show could not be listed.')
  # see: http://flask.pocoo.org/docs/1.0/patterns/flashing/
    return render_template('pages/home.html')

@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def server_error(error):
    return render_template('errors/500.html'), 500


if not app.debug:
    file_handler = FileHandler('error.log')
    file_handler.setFormatter(
        Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    )
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('errors')

#----------------------------------------------------------------------------#
# Launch.
#----------------------------------------------------------------------------#

# Default port:
if __name__ == '__main__':
    app.run()

# Or specify port manually:
'''
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
'''
