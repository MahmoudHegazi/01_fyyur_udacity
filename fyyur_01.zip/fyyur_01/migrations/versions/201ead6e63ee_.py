"""empty message

Revision ID: 201ead6e63ee
Revises: 
Create Date: 2021-01-29 21:47:26.821314

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '201ead6e63ee'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
