window.parseISOString = function parseISOString(s) {
  var b = s.split(/\D+/);
  return new Date(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5], b[6]));
};



/* ---------------- DELETE SHOW AJAX REQUEST -----------------------   */
// this code will be used in delete shows ajax advanced handler UX

const deleteData = async(url = '', data = {}, parent={}) => {
    console.log(data);
    const response = await fetch(url, {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
      },
      // Body data type must match "Content-Type" header
      body: JSON.stringify(data),
    });

    try {
      const newData = await response.json();
      console.log(newData);
      if (newData.cod == 200) {
        // what happend if no error in server delete remove the element parent advanced ajax UX
        // in main.html i added new div with style display none for alert
        // it handle multiple delete without reload the page 0 error full dynamic
        updateui(newData, parent);
      } else {
        alert(newData['message'])
      }
      return newData;
    } catch (error) {
      console.log("error", error);
    }
  }
    const delete_btn = document.querySelectorAll('.delete_show_class');
    // better than  for loop and add function to each button
    window.addEventListener('click',(event)=>{
      if (event.target.classList.contains('delete_show_class')){
        // get the data-show-id arribute which contains the show id
        const showid = event.target.getAttribute('data-show-id');
        const target_parent = event.target.parentElement;
        deleteData('/shows/delete',{show_id:showid},target_parent)
      }
    })


function updateui(newData,parent){
  parent.remove();
  const ajax_flash_cnt = document.querySelector('#ajax_flash_container');
  const server_message = newData.message;
  ajax_flash_cnt.innerHTML = `<a class="close" id="custom_close">&times;</a>AJAX: ${server_message}`;
  const closing_btn = document.querySelector('#custom_close');
  closing_btn.addEventListener('click',()=> {
    ajax_flash_cnt.style.display = 'none';
  })

  ajax_flash_cnt.style.display = 'block';
}




/* ---------------- DELETE Venue AJAX REQUEST -----------------------   */
// this code will be used in delete shows ajax advanced handler UX

const deletVenue = async(url = '', data = {}, parent={}) => {
    console.log(data);
    const response = await fetch(url, {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
      },
      // Body data type must match "Content-Type" header
      body: JSON.stringify(data),
    });

    try {
      const newData = await response.json();
      console.log(newData);
      if (newData.cod == 200) {
        // what happend if no error in server delete remove the element parent advanced ajax UX
        // in main.html i added new div with style display none for alert
        // it handle multiple delete without reload the page 0 error full dynamic
        //updateui_venue(newData, parent);
        alert(newData['message']);
        const host_name = document.location.origin;
        window.location.replace(host_name);

      } else {
        alert(newData.cod);
      }
      return newData;
    } catch (error) {
      console.log("error", error);
    }
  }
    const delete_btn_venues = document.querySelectorAll('.delete_venue_class');
    // better than  for loop and add function to each button
    window.addEventListener('click',(event)=>{
      if (event.target.classList.contains('delete_venue_class')){
        // get the data-show-id arribute which contains the show id
        const venueid = event.target.getAttribute('data-venue-id');
        const target_parent = event.target.parentElement;
        deletVenue(`/venues/${venueid}`,{venue_id:venueid},target_parent)
      }
    })


function updateui_venue(newData,parent){
  parent.remove();
  const ajax_flash_cnt = document.querySelector('#ajax_flash_container');
  const server_message = newData.message;
  ajax_flash_cnt.innerHTML = `<a class="close" id="custom_close">&times;</a>${server_message}`;
  const closing_btn = document.querySelector('#custom_close');
  closing_btn.addEventListener('click',()=> {
    ajax_flash_cnt.style.display = 'none';
  })

  ajax_flash_cnt.style.display = 'block';
}
